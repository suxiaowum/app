// const AJAX_URL = "http://192.168.3.37:8080";
const AJAX_URL = "http://336h3m6273.oicp.vip";

export default{
    AJAX_URL
}