<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
</script>

<style>
html,
body {
  height: 100%;
}
#app {
  width: 100%;
  height: 100%;
}
* {
  margin: 0;
  padding: 0;
}
.el-menu {
  display: flex;
  justify-content: space-between;
}
</style>
